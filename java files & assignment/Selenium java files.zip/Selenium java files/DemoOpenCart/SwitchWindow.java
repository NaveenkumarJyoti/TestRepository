package DemoOpenCart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchWindow {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://lms.novelvista.com/learner-dashboard/506094df-4038-4ec0-ae91-b51cc1c81916");
		
		String parentWindow=driver.getWindowHandle().toString();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//p[contains(text(),'View all practice exams')]")).click();
		Thread.sleep(5000);
		
		driver.switchTo().window("PopupWindow");
		Thread.sleep(3000);
		
		//driver.switchTo().window("parentWindow");
		//Thread.sleep(3000);
		
		//driver.close();
	}

}
