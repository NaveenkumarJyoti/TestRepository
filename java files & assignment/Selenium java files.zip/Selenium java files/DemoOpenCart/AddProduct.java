package DemoOpenCart;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AddProduct {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.opencart.com");
		
		driver.findElement(By.name("search")).sendKeys("iMac");
		driver.findElement(By.xpath("//header/div[1]/div[1]/div[2]/div[1]/span[1]/button[1]")).click();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		//Thread.sleep(3000);
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		
		driver.findElement(By.xpath("//a[contains(text(),'iMac')]")).click();
		
		JavascriptExecutor js1= (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,1000)");
		
		driver.findElement(By.xpath("//a[contains(text(),'Apple Cinema 30\"')]")).click();
		
		JavascriptExecutor js2= (JavascriptExecutor) driver;
		js2.executeScript("window.scrollBy(0,1000)");
		
		WebElement chechBox = driver.findElement(By.name("option[223][]"));
		chechBox.click();
		
		driver.findElement(By.id("input-option208")).clear();
		driver.findElement(By.id("input-option208")).sendKeys("Looking for next day delivery");
		
		Select dropColors = new Select(driver.findElement(By.id("input-option217")));
		dropColors.selectByValue("3");
		
		WebElement uploadImage = driver.findElement(By.id("button-upload222"));
		
		uploadImage.sendKeys("C:\\Users\\NAVEENKUMAR\\Pictures\\Saved Pictures\\pp.jfif");
		
		if(driver.findElement(By.xpath("//body/div[@id='product-product']/div[1]/div[1]/div[1]/div[2]/div[2]/div[11]")).isDisplayed())
		{
			System.out.println("The product info says - "+driver.findElement(By.xpath("//body/div[@id='product-product']/div[1]/div[1]/div[1]/div[2]/div[2]/div[11]")).getText());
		}
		
		//clicking on Add to Cart
		JavascriptExecutor js3= (JavascriptExecutor) driver;
		js3.executeScript("window.scrollBy(0,1000)");
		
		driver.findElement(By.xpath("//button[@id='button-cart']")).click();
		System.out.println("Added to Cart");
	}

}
