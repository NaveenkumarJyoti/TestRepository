package Advanced;

import org.testng.annotations.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class JavaScriptExecutor {
		
		@Test
		public void Login() throws InterruptedException {
			String driverPath="C:\\\\\\\\Users\\\\\\\\NAVEENKUMAR\\\\\\\\Desktop\\\\\\\\Selenium\\\\\\\\selenium jars\\\\\\\\geckodriver-v0.31.0-win64\\\\\\\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", driverPath);
			WebDriver driver=new FirefoxDriver();
			driver.get("https://demo.opencart.com/");
			
			JavaScriptExecutor js=(JavaScriptExecutor)driver;
			WebElement userEmail=driver.findElement(By.name("email"));
			WebElement password=driver.findElement(By.name("password"));
			WebElement loginButton=driver.findElement(By.xpath("//body/div[@id='account-login']/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/input[1]"));
			
			js.executeScript("");
			
			js.executScript("alert('Welcome');");
			Alert alt=driver.switchTo().alert();
			alt.accept();
			
			String text=js.executScript("return document.title;").toString();
			System.out.println("The page title is "+text);
			
			driver.close();
	}
}
