package Assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SwitchWindowExercise {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
//		WebDriver driver=new ChromeDriver();
//		driver.get("https://demo.opencart.com");
		
		System.setProperty("webdriver.gecko.driver","C:\\\\Users\\\\NAVEENKUMAR\\\\Desktop\\\\Selenium\\\\selenium jars\\\\geckodriver-v0.31.0-win64\\\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demo.opencart.com");
		
		//storing the name of current(parent) window
		String parentWindow=driver.getWindowHandle().toString();
		Thread.sleep(2000);
		
		driver.findElement(By.name("search")).sendKeys("iMac");
		driver.findElement(By.xpath("//header/div[1]/div[1]/div[2]/div[1]/span[1]/button[1]")).click();
		
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		Thread.sleep(3000);
		
		Select dropColors = new Select(driver.findElement(By.id("input-sort")));
		dropColors.selectByValue("https://demo.opencart.com/index.php?route=product/search&sort=p.price&order=ASC&search=iMac");
		Thread.sleep(2000);
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		
		driver.findElement(By.xpath("//a[contains(text(),'iMac')]")).click();
		
		JavascriptExecutor js1= (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,1000)");
		
		driver.findElement(By.xpath("//a[contains(text(),'Apple Cinema 30\"')]")).click();
		
		JavascriptExecutor js2= (JavascriptExecutor) driver;
		js2.executeScript("window.scrollBy(0,1000)");
				
//		WebElement uploadImage = driver.findElement(By.id("button-upload222"));
//		uploadImage.sendKeys("C:\\Users\\NAVEENKUMAR\\Pictures\\Saved Pictures\\pp.jfif");

		driver.findElement(By.id("button-cart")).click();
		Thread.sleep(2000);
		
		//going back to iMac
		if(driver.findElement(By.className("text-danger")).isDisplayed()) {
			driver.navigate().back();
		}
		Thread.sleep(1000);
		
		js2.executeScript("window.scrollBy(0, -500)");
		
		//String parentWindow1=driver.getWindowHandle().toString();
		
		System.out.println(driver.getTitle());
		
		//clicking on tweet
		driver.findElement(By.xpath("//iframe[@id='twitter-widget-0']")).click();
		Thread.sleep(5000);
//		driver.switchTo().newWindow(WindowType.WINDOW);
//		driver.findElement(By.xpath("(//span[contains(.,'Log in')])[3]")).click();
//		System.out.println(driver.getTitle());

		driver.switchTo().window(driver.getWindowHandle());
		Thread.sleep(3000);
		
		System.out.println(driver.getTitle());
		
		
		//driver.close();
	}

}
