package DemoOpenCart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchFrame {
	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("http://demo.guru99.com/selenium/deprecated.html");
		
		driver.switchTo().frame("packageFrame");
		driver.findElement(By.linkText("AbstractWebDriverEventListener")).click();
		Thread.sleep(3000);
		//driver.close();
	}
}
