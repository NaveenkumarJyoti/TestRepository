package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddToExercise12 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://demo.opencart.com/index.php?route=product/product&product_id=41&search=iMac");
		
		driver.findElement(By.id("button-cart")).click();
		Thread.sleep(3000);
		
		if(driver.findElement(By.linkText("shopping cart")).isDisplayed()) {
			driver.findElement(By.linkText("shopping cart")).click();
		}
		
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]/div[1]/input[1]")).sendKeys("4");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//tbody/tr[1]/td[4]/div[1]/span[1]/button[1]")).click();
		Thread.sleep(3000);
		
		if(driver.findElement(By.xpath("//body/div[@id='checkout-cart']/div[1]")).isDisplayed()) {
			System.out.println(driver.findElement(By.xpath("//body/div[@id='checkout-cart']/div[1]")).getText());
		}
		
		JavascriptExecutor js3= (JavascriptExecutor) driver;
		js3.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Continue Shopping")).click();
		
		driver.close();	
		}
}
