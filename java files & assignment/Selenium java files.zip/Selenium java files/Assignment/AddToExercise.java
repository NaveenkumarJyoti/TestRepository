package Assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddToExercise {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NAVEENKUMAR\\Desktop\\Selenium\\selenium jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://demo.opencart.com/index.php?route=product/product&product_id=41&search=iMac");
		
//----------Click on tweet and open in same window---------------------
//		//driver.switchTo().frame(0);
//		//System.out.println("swithed to twitter widget frame");
//		driver.findElement(By.linkText("Tweet")).click();
//		
//		System.out.println(driver.getTitle());
		
		String iMac=driver.getWindowHandle().toString();
		
		driver.findElement(By.xpath("//div[@class='tweet_iframe_widget']")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3) );
		
		driver.switchTo().window(driver.getWindowHandle());
		Thread.sleep(3000);
		
		System.out.println(driver.getTitle());
		
		WebElement floating=driver.findElement(By.xpath("//span[contains(text(),'Want to log in first?')]"));
		System.out.println(floating.getText());
		
		driver.findElement(By.xpath("//span[contains(text(),'Log in')]"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		System.out.println(driver.getTitle());
		
		//driver.switchTo().window("iMac");
		driver.navigate().back();
		System.out.println(driver.getTitle());
		
		driver.close();
	}

}
